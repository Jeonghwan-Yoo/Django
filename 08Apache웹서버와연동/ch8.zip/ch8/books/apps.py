from django.apps import AppConfig


class BooksConfig(AppConfig):
    name = 'books'
    verbose_name = 'Book-Author_Publisher App' #추가
    
